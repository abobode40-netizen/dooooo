import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const toolDefinitions = [
  { type: "function", function: { name: "get_sales_summary", description: "احسب ملخص المبيعات للفترة المحددة من فواتير البيع الفعلية.", parameters: { type: "object", properties: { from: { type: "string", description: "تاريخ البداية YYYY-MM-DD" }, to: { type: "string", description: "تاريخ النهاية YYYY-MM-DD" } }, required: ["from", "to"] } } },
  { type: "function", function: { name: "get_top_products", description: "اعرض أكثر الأصناف مبيعاً خلال فترة.", parameters: { type: "object", properties: { from: { type: "string" }, to: { type: "string" }, limit: { type: "number" } }, required: ["from", "to"] } } },
  { type: "function", function: { name: "get_inventory_summary", description: "اعرض المخزون الحالي وقيمته والأصناف القريبة من النفاد.", parameters: { type: "object", properties: { threshold: { type: "number", description: "حد النفاد، الافتراضي 10" } } } } },
  { type: "function", function: { name: "search_products", description: "ابحث عن صنف فعلياً بالكود أو الاسم أو الباركود واعرض سعره ومخزونه.", parameters: { type: "object", properties: { query: { type: "string" }, limit: { type: "number" } }, required: ["query"] } } },
  { type: "function", function: { name: "get_price_changes", description: "اعرض الزيادات والنقصان في أسعار الأصناف خلال فترة.", parameters: { type: "object", properties: { from: { type: "string" }, to: { type: "string" }, limit: { type: "number" } }, required: ["from", "to"] } } },
  { type: "function", function: { name: "get_shortages", description: "اعرض قائمة النواقص الحالية أو خلال فترة.", parameters: { type: "object", properties: { from: { type: "string" }, to: { type: "string" }, only_open: { type: "boolean" } } } } },
  { type: "function", function: { name: "get_new_products", description: "اعرض الأصناف الجديدة التي أضيفت خلال فترة.", parameters: { type: "object", properties: { from: { type: "string" }, to: { type: "string" }, limit: { type: "number" } }, required: ["from", "to"] } } },
  { type: "function", function: { name: "get_customer_balance", description: "اعرض مديونية عميل أو أعلى العملاء مديونية.", parameters: { type: "object", properties: { customer_name: { type: "string" }, limit: { type: "number" } } } } },
  { type: "function", function: { name: "get_product_sales", description: "اعرض حركة صنف محدد خلال فترة.", parameters: { type: "object", properties: { product_name: { type: "string" }, from: { type: "string" }, to: { type: "string" } }, required: ["product_name", "from", "to"] } } },
  { type: "function", function: { name: "search_invoices", description: "ابحث عن فواتير فعلية برقم الفاتورة أو اسم العميل أو فترة.", parameters: { type: "object", properties: { query: { type: "string" }, from: { type: "string" }, to: { type: "string" }, limit: { type: "number" } } } } },
  { type: "function", function: { name: "get_invoice_details", description: "اعرض تفاصيل فاتورة محددة.", parameters: { type: "object", properties: { invoice_id: { type: "string" } }, required: ["invoice_id"] } } },
  { type: "function", function: { name: "compare_periods", description: "قارن إجمالي المبيعات بين فترتين فعليتين.", parameters: { type: "object", properties: { first_from: { type: "string" }, first_to: { type: "string" }, second_from: { type: "string" }, second_to: { type: "string" } }, required: ["first_from", "first_to", "second_from", "second_to"] } } },
] as const;

const unavailable = "هذا السؤال خارج نطاق المساعد الحالي. المتاح فعلياً: المنتجات، البحث عن الأصناف، المخزون، المبيعات، الفواتير، العملاء، الزيادات والنقصان في الأسعار، النواقص، والأصناف الجديدة.";
const json = (value: unknown) => JSON.stringify(value);
// التواريخ تُفسَّر بتوقيت القاهرة (UTC+2 / +3 صيفاً) وليس UTC، وإلا تتأخر/تتقدم مبيعات اليوم عن موعدها
const TZ = "Africa/Cairo";
function cairoOffset(date: string): string {
  const part = new Intl.DateTimeFormat("en-US", { timeZone: TZ, timeZoneName: "longOffset" })
    .formatToParts(new Date(`${date}T12:00:00Z`)).find((p) => p.type === "timeZoneName")?.value ?? "GMT+02:00";
  return part.match(/GMT([+-]\d{2}:\d{2})/)?.[1] ?? "+02:00";
}
const dayStart = (value: string) => `${value}T00:00:00.000${cairoOffset(value)}`;
const dateEnd = (value: string) => `${value}T23:59:59.999${cairoOffset(value)}`;
const cairoDay = (iso: string) => new Date(iso).toLocaleDateString("en-CA", { timeZone: TZ });
const isDate = (v: unknown): v is string => typeof v === "string" && /^\d{4}-\d{2}-\d{2}$/.test(v);
const isUuid = (v: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v);
const sanitize = (v: string) => v.replace(/[,%()"'\\*:]/g, " ").trim(); // رموز لها معنى داخل فلاتر PostgREST

// PostgREST يقطع النتائج عند 1000 صف افتراضياً → نقرأ على صفحات حتى لا تكون المجاميع ناقصة بصمت
// deno-lint-ignore no-explicit-any
async function fetchAll<T>(build: () => any): Promise<T[]> {
  const out: T[] = []; const size = 1000;
  for (let from = 0; ; from += size) {
    const { data, error } = await build().range(from, from + size - 1);
    if (error) throw error;
    if (!data?.length) break;
    out.push(...(data as T[]));
    if (data.length < size) break;
  }
  return out;
}
const geminiTools = [{ functionDeclarations: toolDefinitions.map((tool) => ({ name: tool.function.name, description: tool.function.description, parameters: tool.function.parameters })) }];
const systemInstruction = `أنت مساعد ذكي عربي داخل برنامج إدارة مبيعات ومخزون. نطاقك فقط: المنتجات، البحث عن الأصناف، المخزون، المبيعات، الفواتير، العملاء، الزيادات والنقصان في الأسعار، النواقص، والأصناف الجديدة. لا تخمن أي رقم؛ استخدم الأدوات دائماً لجلب البيانات الفعلية. كل الأرقام بالجنيه المصري EGP. اذكر الفترة وطريقة الحساب ومصدر النتيجة. إذا كان السؤال خارج النطاق قل إنه غير متاح بدلاً من اختلاق نتيجة. أنت للقراءة والتحليل فقط ولا تعدّل البيانات.`;

async function queryTool(name: string, args: Record<string, unknown>, db: ReturnType<typeof createClient>): Promise<unknown> {
  if (["get_supplier_balance", "get_purchases_summary", "get_expenses_summary", "get_returns_summary"].includes(name)) return { unavailable };
  for (const key of ["from", "to", "first_from", "first_to", "second_from", "second_to"]) {
    if (args[key] !== undefined && args[key] !== null && args[key] !== "" && !isDate(args[key])) throw new Error(`تاريخ غير صالح في الحقل ${key} — الصيغة المطلوبة YYYY-MM-DD`);
  }
  if (name === "get_sales_summary") {
    const from = String(args.from); const to = String(args.to);
    const rows = await fetchAll<{ id: string; total: number; created_at: string; customer_id: string | null; customer_name: string | null }>(() => db.from("sales").select("id,total,created_at,customer_id,customer_name").gte("created_at", dayStart(from)).lte("created_at", dateEnd(to)).order("created_at", { ascending: true }).order("id"));
    const total = rows.reduce((sum, row) => sum + Number(row.total || 0), 0);
    const byDay = rows.reduce<Record<string, number>>((out, row) => { const day = cairoDay(row.created_at); out[day] = (out[day] || 0) + Number(row.total || 0); return out; }, {});
    return { from, to, currency: "EGP", total_sales: total, invoice_count: rows.length, average_invoice: rows.length ? total / rows.length : 0, by_day: byDay, note: "المبيعات محسوبة من إجمالي فواتير البيع، ولا يوجد جدول مرتجعات أو مدفوعات مستقل حالياً." };
  }
  if (name === "get_top_products") {
    const from = String(args.from); const to = String(args.to); const limit = Math.min(Number(args.limit || 10), 50);
    const items = await fetchAll<{ name: string; product_id: string | null; quantity: number; subtotal: number }>(() => db.from("sale_items").select("name,product_id,quantity,subtotal,sales!inner(created_at)").gte("sales.created_at", dayStart(from)).lte("sales.created_at", dateEnd(to)).order("id"));
    if (!items.length) return { from, to, products: [] };
    const grouped = new Map<string, { name: string; quantity: number; sales: number }>();
    for (const item of items) { const key = item.product_id || item.name; const old = grouped.get(key) || { name: item.name, quantity: 0, sales: 0 }; old.quantity += Number(item.quantity || 0); old.sales += Number(item.subtotal || 0); grouped.set(key, old); }
    return { from, to, currency: "EGP", products: [...grouped.values()].sort((a, b) => b.quantity - a.quantity).slice(0, limit) };
  }
  if (name === "get_inventory_summary") {
    const threshold = Number(args.threshold ?? 10);
    const products = await fetchAll<{ id: string; name: string; code: string | null; stock: number; price: number; cost: number; unit: string | null }>(() => db.from("products").select("id,name,code,stock,price,cost,unit").order("stock", { ascending: true }).order("id"));
    return { currency: "EGP", product_count: products.length, inventory_value_at_cost: products.reduce((sum, p) => sum + Number(p.stock || 0) * Number(p.cost || 0), 0), low_stock: products.filter(p => Number(p.stock) <= threshold).slice(0, 100), all_stock: products.slice(0, 200) };
  }
  if (name === "search_products") {
    const queryText = String(args.query || "").trim(); const safeText = sanitize(queryText); const limit = Math.min(Number(args.limit || 30), 100);
    const { data, error } = await db.from("products").select("id,name,code,barcode,unit,price,price_wholesale,cost,stock,category,created_at").or(`name.ilike.%${safeText}%,code.ilike.%${safeText}%,barcode.ilike.%${safeText}%`).limit(limit);
    if (error) throw error; return { query: queryText, products: data ?? [], currency: "EGP" };
  }
  if (name === "get_price_changes") {
    const from = String(args.from); const to = String(args.to); const limit = Math.min(Number(args.limit || 100), 200);
    const { data: days, error: dayError } = await db.from("price_change_days").select("id,day_date").gte("day_date", from).lte("day_date", to);
    if (dayError) throw dayError;
    const dayIds = (days ?? []).map((d: { id: string }) => d.id); if (!dayIds.length) return { from, to, changes: [], note: "القيم مأخوذة من سجل تغييرات الأسعار الفعلي." };
    const { data, error } = await db.from("price_change_items").select("product_name,code,price_wholesale,price_retail,old_price_wholesale,old_price_retail,is_new,created_at").in("day_id", dayIds).order("created_at", { ascending: false }).limit(limit);
    if (error) throw error; return { from, to, changes: data ?? [], note: "القيم مأخوذة من سجل تغييرات الأسعار الفعلي." };
  }
  if (name === "get_shortages") {
    let dayQuery = db.from("shortage_lists").select("id,list_date").order("list_date", { ascending: false }).limit(200);
    if (args.from) dayQuery = dayQuery.gte("list_date", String(args.from)); if (args.to) dayQuery = dayQuery.lte("list_date", String(args.to));
    const { data: lists, error: listError } = await dayQuery; if (listError) throw listError;
    const listIds = (lists ?? []).map((l: { id: string }) => l.id); if (!listIds.length) return { shortages: [] };
    let query = db.from("shortage_items").select("product_name,product_id,notes,arrived,created_at").in("list_id", listIds).order("created_at", { ascending: false }).limit(200);
    if (args.only_open !== false) query = query.eq("arrived", false);
    const { data, error } = await query; if (error) throw error; return { shortages: data ?? [] };
  }
  if (name === "get_new_products") {
    const from = String(args.from); const to = String(args.to); const limit = Math.min(Number(args.limit || 100), 200);
    const { data, error } = await db.from("products").select("id,name,code,unit,price,price_wholesale,cost,stock,category,created_at").gte("created_at", dayStart(from)).lte("created_at", dateEnd(to)).order("created_at", { ascending: false }).limit(limit);
    if (error) throw error; return { from, to, products: data ?? [] };
  }
  if (name === "get_customer_balance") {
    const customerName = String(args.customer_name || "").trim(); const limit = Math.min(Number(args.limit || 20), 100);
    let query = db.from("customer_debts").select("customer_id,customer_name,customer_phone,account_total,paid_amount,remaining,updated_at").order("remaining", { ascending: false }).limit(limit);
    if (customerName) query = query.ilike("customer_name", `%${sanitize(customerName)}%`);
    const { data, error } = await query; if (error) throw error;
    return { currency: "EGP", customers: data ?? [], note: "الرصيد مأخوذ من جدول مديونيات العملاء." };
  }
  if (name === "get_product_sales") {
    const productName = String(args.product_name); const from = String(args.from); const to = String(args.to);
    const { data: products, error: productError } = await db.from("products").select("id,name").ilike("name", `%${sanitize(productName)}%`).limit(5); if (productError) throw productError;
    const productIds = (products ?? []).map((p: { id: string }) => p.id); if (!productIds.length) return { product_name: productName, sales: [] };
    const items = await fetchAll<Record<string, unknown>>(() => db.from("sale_items").select("name,quantity,subtotal,sale_id,sales!inner(created_at)").in("product_id", productIds).gte("sales.created_at", dayStart(from)).lte("sales.created_at", dateEnd(to)).order("id"));
    return { product_name: productName, from, to, items };
  }
  if (name === "search_invoices") {
    const queryText = String(args.query || "").trim(); const safeText = sanitize(queryText); const limit = Math.min(Number(args.limit || 30), 100); let query = db.from("sales").select("id,invoice_number,total,created_at,customer_name,customer_phone,items_count,discount").order("created_at", { ascending: false }).limit(limit);
    if (args.from) query = query.gte("created_at", dayStart(String(args.from))); if (args.to) query = query.lte("created_at", dateEnd(String(args.to))); if (safeText) query = query.or(`invoice_number.ilike.%${safeText}%,customer_name.ilike.%${safeText}%`);
    const { data, error } = await query; if (error) throw error; return { invoices: data ?? [] };
  }
  if (name === "get_invoice_details") {
    const id = String(args.invoice_id).trim(); const { data: invoice, error } = await (isUuid(id) ? db.from("sales").select("*").eq("id", id) : db.from("sales").select("*").eq("invoice_number", id)).limit(1).maybeSingle(); if (error) throw error; if (!invoice) return { invoice: null };
    const { data: items, error: itemError } = await db.from("sale_items").select("*").eq("sale_id", (invoice as { id: string }).id); if (itemError) throw itemError; return { invoice, items: items ?? [] };
  }
  if (name === "compare_periods") {
    const periods = [[String(args.first_from), String(args.first_to)], [String(args.second_from), String(args.second_to)]]; const results = [];
    for (const [from, to] of periods) { const data = await fetchAll<{ total: number }>(() => db.from("sales").select("total").gte("created_at", dayStart(from)).lte("created_at", dateEnd(to)).order("id")); results.push({ from, to, total_sales: data.reduce((sum, row) => sum + Number(row.total || 0), 0), invoice_count: data.length }); }
    const difference = Number(results[1].total_sales) - Number(results[0].total_sales); return { first: results[0], second: results[1], difference, percentage_change: Number(results[0].total_sales) ? (difference / Number(results[0].total_sales)) * 100 : null, currency: "EGP" };
  }
  return { unavailable };
}

function localDateRange(question: string): { from: string; to: string } {
  const to = cairoDay(new Date().toISOString());
  if (/الشهر|شهر|month/i.test(question)) return { from: `${to.slice(0, 8)}01`, to };
  return { from: to, to };
}

function formatMoney(value: unknown): string { return `${Number(value || 0).toLocaleString("ar-EG", { maximumFractionDigits: 2 })} جنيه مصري`; }

async function askLocally(question: string, db: ReturnType<typeof createClient>): Promise<string> {
  const range = localDateRange(question);
  if (/مبيعات|فاتورة|فواتير|باع|بيع/.test(question)) {
    const data = await queryTool("get_sales_summary", range, db) as { total_sales: number; invoice_count: number; average_invoice: number; from: string; to: string };
    if (/أكثر|اكتر|الأصناف|اصناف|منتجات/.test(question)) {
      const top = await queryTool("get_top_products", { ...range, limit: 10 }, db) as { products: Array<{ name: string; quantity: number; sales: number }> };
      return top.products.length ? `أكثر الأصناف مبيعاً من ${range.from} إلى ${range.to}:\n${top.products.map((item, index) => `${index + 1}. ${item.name} — ${item.quantity} وحدة — ${formatMoney(item.sales)}`).join("\n")}` : "لا توجد مبيعات مسجلة لهذه الفترة.";
    }
    return `ملخص المبيعات من ${data.from} إلى ${data.to}:\nإجمالي المبيعات: ${formatMoney(data.total_sales)}\nعدد الفواتير: ${data.invoice_count}\nمتوسط الفاتورة: ${formatMoney(data.average_invoice)}\nالحساب مبني على إجمالي فواتير البيع الفعلية.`;
  }
  if (/نواقص|ناقص|تخلص|نفاد/.test(question)) {
    const data = await queryTool("get_shortages", { only_open: true }, db) as { shortages: Array<{ product_name: string; notes: string | null }> };
    return data.shortages.length ? `النواقص المفتوحة (${data.shortages.length}):\n${data.shortages.map(item => `- ${item.product_name}${item.notes ? ` — ${item.notes}` : ""}`).join("\n")}` : "لا توجد نواقص مفتوحة حالياً.";
  }
  if (/جديد|جديدة|مضاف/.test(question)) {
    const data = await queryTool("get_new_products", { ...range, limit: 50 }, db) as { products: Array<{ name: string; price: number; stock: number }> };
    return data.products.length ? `الأصناف المضافة من ${range.from} إلى ${range.to}:\n${data.products.map(item => `- ${item.name} — السعر ${formatMoney(item.price)} — المخزون ${item.stock}`).join("\n")}` : "لا توجد أصناف جديدة في هذه الفترة.";
  }
  if (/زيادة|نقصان|أسعار|اسعار|سعر/.test(question)) {
    const data = await queryTool("get_price_changes", { ...range, limit: 100 }, db) as { changes: Array<{ product_name: string; old_price_retail: number; price_retail: number; is_new: boolean }> };
    return data.changes.length ? `تغييرات الأسعار من ${range.from} إلى ${range.to}:\n${data.changes.map(item => `- ${item.product_name} — ${item.is_new ? "صنف جديد" : `${formatMoney(item.old_price_retail)} إلى ${formatMoney(item.price_retail)}`}`).join("\n")}` : "لا توجد تغييرات أسعار مسجلة لهذه الفترة.";
  }
  if (/مخزون|أصناف|اصناف|ابحث|بحث|كود|باركود/.test(question)) {
    const search = question.replace(/ابحث|بحث|عن|صنف|الصنف|المخزون|عندي|ما هو|ايه|إيه/g, " ").trim();
    if (search.length > 1) {
      const data = await queryTool("search_products", { query: search, limit: 20 }, db) as { products: Array<{ name: string; code: string | null; stock: number; price: number }> };
      return data.products.length ? data.products.map(item => `- ${item.name} — المخزون ${item.stock} — السعر ${formatMoney(item.price)}${item.code ? ` — الكود ${item.code}` : ""}`).join("\n") : "لم أجد صنفاً مطابقاً.";
    }
    const data = await queryTool("get_inventory_summary", { threshold: 10 }, db) as { product_count: number; inventory_value_at_cost: number; low_stock: Array<{ name: string; stock: number }> };
    return `ملخص المخزون: ${data.product_count} صنف\nقيمة المخزون بالتكلفة: ${formatMoney(data.inventory_value_at_cost)}\nالأصناف القريبة من النفاد: ${data.low_stock.length}`;
  }
  if (/عميل|عملاء|مديون|فلوس|حساب/.test(question)) {
    const name = question.replace(/مين|أكثر|العملاء|العملاء|مديونية|مديون|عليه|فلوس|حساب|عميل/g, " ").trim();
    const data = await queryTool("get_customer_balance", { customer_name: name.length > 1 ? name : undefined, limit: 20 }, db) as { customers: Array<{ customer_name: string; remaining: number }> };
    return data.customers.length ? `مديونيات العملاء:\n${data.customers.map(item => `- ${item.customer_name}: ${formatMoney(item.remaining)}`).join("\n")}` : "لا توجد مديونية مسجلة بهذا الاسم.";
  }
  return "أستطيع حالياً الإجابة عن المبيعات، الأصناف والمخزون، البحث بالاسم أو الكود، العملاء، الزيادات والنواقص في الأسعار، النواقص، والأصناف الجديدة. جرّب سؤالاً محدداً مثل: كم مبيعات اليوم؟";
}

async function askGemini(apiKey: string, messages: Array<{ role: "user" | "assistant"; content: string }>, db: ReturnType<typeof createClient>): Promise<string> {
  const contents: Array<Record<string, unknown>> = messages.map((message) => ({ role: message.role === "assistant" ? "model" : "user", parts: [{ text: message.content }] }));
  for (let round = 0; round < 4; round++) {
    const model = Deno.env.get("GEMINI_MODEL") || "gemini-2.5-flash";
    const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey }, body: json({ systemInstruction: { parts: [{ text: systemInstruction }] }, contents, tools: geminiTools, generationConfig: { temperature: 0.1, maxOutputTokens: 1800 } }) });
    if (!response.ok) throw new Error("Gemini request failed");
    const result = await response.json(); const parts = result.candidates?.[0]?.content?.parts ?? [];
    const functionCall = parts.find((part: { functionCall?: unknown }) => part.functionCall)?.functionCall as { name: string; args?: Record<string, unknown> } | undefined;
    if (!functionCall) return parts.filter((part: { text?: string }) => part.text).map((part: { text: string }) => part.text).join("\n") || "لم أتمكن من تكوين إجابة.";
    contents.push({ role: "model", parts });
    let data: unknown;
    try { data = await queryTool(functionCall.name, functionCall.args || {}, db); } catch (e) { data = { error: e instanceof Error ? e.message : "tool failed" }; }
    // Gemini يتوقع كائناً في response
    contents.push({ role: "user", parts: [{ functionResponse: { name: functionCall.name, response: { result: data } } }] });
  }
  throw new Error("Gemini analysis limit reached");
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  try {
    const openAiKey = Deno.env.get("OPENAI_API_KEY"); const geminiKey = Deno.env.get("GEMINI_API_KEY"); const supabaseUrl = Deno.env.get("SUPABASE_URL"); const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) return new Response(json({ error: "تعذر الوصول إلى بيانات البرنامج حالياً." }), { status: 503, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    const body = await req.json().catch(() => ({})) as { messages?: Array<{ role: "user" | "assistant"; content: string }> };
    // نقبل فقط رسائل نصية بأدوار صحيحة، ونبدأ دائماً برسالة مستخدم
    let messages = (Array.isArray(body.messages) ? body.messages : [])
      .filter((m) => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string" && m.content.trim())
      .map((m) => ({ role: m.role, content: m.content.slice(0, 2000) }))
      .slice(-12);
    while (messages.length && messages[0].role !== "user") messages = messages.slice(1);
    if (!messages.length) return new Response(json({ error: "لا توجد رسالة للتحليل." }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    const db = createClient(supabaseUrl, serviceKey);
    if (!openAiKey && !geminiKey) {
      const latest = messages[messages.length - 1]?.content || "";
      const answer = await askLocally(latest, db);
      return new Response(json({ answer, mode: "local" }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (geminiKey) {
      const answer = await askGemini(geminiKey, messages, db);
      return new Response(json({ answer }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    let conversation: Array<Record<string, unknown>> = [{ role: "system", content: systemInstruction }, ...messages];
    for (let round = 0; round < 4; round++) {
      const response = await fetch("https://api.openai.com/v1/chat/completions", { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${openAiKey}` }, body: json({ model: "gpt-4o-mini", temperature: 0.1, messages: conversation, tools: toolDefinitions, tool_choice: "auto" }) });
      if (!response.ok) return new Response(json({ error: "تعذر الاتصال بخدمة الذكاء الاصطناعي حالياً." }), { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      const result = await response.json(); const choice = result.choices?.[0]?.message; if (!choice) throw new Error("No assistant response");
      conversation.push(choice);
      if (!choice.tool_calls?.length) return new Response(json({ answer: choice.content || "لم أتمكن من تكوين إجابة." }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });
      for (const call of choice.tool_calls as Array<{ id: string; function: { name: string; arguments: string } }>) { let data: unknown; try { data = await queryTool(call.function.name, JSON.parse(call.function.arguments || "{}"), db); } catch (e) { data = { error: e instanceof Error ? e.message : "tool failed" }; } conversation.push({ role: "tool", tool_call_id: call.id, content: json(data) }); }
    }
    return new Response(json({ error: "تعذر إكمال التحليل." }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (catchedError) {
    const message = catchedError instanceof Error ? catchedError.message : "حدث خطأ أثناء تحليل السؤال.";
    return new Response(json({ error: message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
