CREATE TABLE IF NOT EXISTS sales (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  invoice_number TEXT NOT NULL,
  total DECIMAL(10,2) DEFAULT 0,
  discount DECIMAL(10,2) DEFAULT 0,
  items_count INTEGER DEFAULT 0,
  price_mode TEXT DEFAULT 'wholesale',
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS sale_items (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  sale_id UUID REFERENCES sales(id) ON DELETE CASCADE,
  product_id UUID,
  name TEXT NOT NULL,
  code TEXT,
  unit TEXT,
  price DECIMAL(10,2) DEFAULT 0,
  quantity DECIMAL(10,3) DEFAULT 1,
  subtotal DECIMAL(10,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE sales ENABLE ROW LEVEL SECURITY;
ALTER TABLE sale_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "sales_select"      ON sales FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "sales_insert"      ON sales FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "sales_update"      ON sales FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "sales_delete"      ON sales FOR DELETE TO anon, authenticated USING (true);

CREATE POLICY "sale_items_select" ON sale_items FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "sale_items_insert" ON sale_items FOR INSERT TO anon, authenticated WITH CHECK (true);
CREATE POLICY "sale_items_update" ON sale_items FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
CREATE POLICY "sale_items_delete" ON sale_items FOR DELETE TO anon, authenticated USING (true);
