ALTER TABLE sales ADD COLUMN IF NOT EXISTS invoice_number TEXT;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS discount DECIMAL(10,2) DEFAULT 0;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS price_mode TEXT DEFAULT 'wholesale';
ALTER TABLE sales ADD COLUMN IF NOT EXISTS notes TEXT;

ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS code TEXT;
ALTER TABLE sale_items ADD COLUMN IF NOT EXISTS unit TEXT;

-- Backfill invoice_number for any existing rows (none expected)
UPDATE sales SET invoice_number = id::text WHERE invoice_number IS NULL;

-- Make sure RLS policies exist (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sales' AND policyname = 'sales_select') THEN
    CREATE POLICY "sales_select" ON sales FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sales' AND policyname = 'sales_insert') THEN
    CREATE POLICY "sales_insert" ON sales FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sales' AND policyname = 'sales_update') THEN
    CREATE POLICY "sales_update" ON sales FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sales' AND policyname = 'sales_delete') THEN
    CREATE POLICY "sales_delete" ON sales FOR DELETE TO anon, authenticated USING (true);
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sale_items' AND policyname = 'sale_items_select') THEN
    CREATE POLICY "sale_items_select" ON sale_items FOR SELECT TO anon, authenticated USING (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sale_items' AND policyname = 'sale_items_insert') THEN
    CREATE POLICY "sale_items_insert" ON sale_items FOR INSERT TO anon, authenticated WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sale_items' AND policyname = 'sale_items_update') THEN
    CREATE POLICY "sale_items_update" ON sale_items FOR UPDATE TO anon, authenticated USING (true) WITH CHECK (true);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_policies WHERE tablename = 'sale_items' AND policyname = 'sale_items_delete') THEN
    CREATE POLICY "sale_items_delete" ON sale_items FOR DELETE TO anon, authenticated USING (true);
  END IF;
END $$;
