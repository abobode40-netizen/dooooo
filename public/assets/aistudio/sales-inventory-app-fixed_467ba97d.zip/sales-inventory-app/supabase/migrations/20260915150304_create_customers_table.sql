/*
# Create customers table (قائمة العملاء)

1. New Tables
- `customers`
  - `id` (uuid, primary key)
  - `code` (text, unique, nullable) — كود العميل
  - `name` (text, not null) — اسم العميل
  - `phone1` (text, nullable) — رقم الهاتف الأول
  - `phone2` (text, nullable) — رقم الهاتف الثاني
  - `notes` (text, nullable) — ملاحظات
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

2. Modified Tables
- `sales`: add `customer_id` (uuid, nullable FK to customers, ON DELETE SET NULL)
- `customer_debts`: add `customer_id` (uuid, nullable FK to customers, ON DELETE SET NULL)

3. Security
- Enable RLS on `customers`.
- Allow anon + authenticated CRUD (single-tenant, no sign-in app).
*/

CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code text UNIQUE,
  name text NOT NULL,
  phone1 text,
  phone2 text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE customers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_customers" ON customers;
CREATE POLICY "anon_select_customers" ON customers FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_customers" ON customers;
CREATE POLICY "anon_insert_customers" ON customers FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_customers" ON customers;
CREATE POLICY "anon_update_customers" ON customers FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_customers" ON customers;
CREATE POLICY "anon_delete_customers" ON customers FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_customers_code ON customers (code);
CREATE INDEX IF NOT EXISTS idx_customers_name ON customers (name);

-- Link sales to customers
ALTER TABLE sales ADD COLUMN IF NOT EXISTS customer_id uuid REFERENCES customers(id) ON DELETE SET NULL;

-- Link customer_debts to customers
ALTER TABLE customer_debts ADD COLUMN IF NOT EXISTS customer_id uuid REFERENCES customers(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_sales_customer_id ON sales (customer_id);
CREATE INDEX IF NOT EXISTS idx_customer_debts_customer_id ON customer_debts (customer_id);
