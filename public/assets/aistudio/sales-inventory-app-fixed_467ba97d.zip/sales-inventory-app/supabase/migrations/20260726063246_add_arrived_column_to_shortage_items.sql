/*
# إضافة خانة "وصل" لأصناف النواقص

1. تعديلات
   - `shortage_items`: إضافة عمود `arrived` (boolean, default false)
     لتحديد ما إذا كان الصنف الناقص قد وصل أم لا.

2. الأمان
   - لا تغيير في السياسات (CRUD مفتوح لـ anon و authenticated بالفعل).
*/

ALTER TABLE shortage_items
  ADD COLUMN IF NOT EXISTS arrived boolean NOT NULL DEFAULT false;
