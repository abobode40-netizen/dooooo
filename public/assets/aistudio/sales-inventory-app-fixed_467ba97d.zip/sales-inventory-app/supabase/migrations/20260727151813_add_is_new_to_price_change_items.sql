ALTER TABLE price_change_items
  ADD COLUMN IF NOT EXISTS is_new boolean NOT NULL DEFAULT false;
