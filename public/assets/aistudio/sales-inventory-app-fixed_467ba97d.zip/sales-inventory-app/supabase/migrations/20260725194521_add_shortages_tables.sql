/*
# جداول النواقص (Shortages)

1. جداول جديدة
   - `shortage_lists`: قائمة نواقص يومية، كل يوم له قائمة واحدة
     - id (uuid, primary key)
     - list_date (date, unique) — تاريخ اليوم
     - archived_at (timestamptz) — وقت الأرشفة
     - created_at (timestamptz)
     - updated_at (timestamptz)
   - `shortage_items`: أصناف داخل كل قائمة نواقص
     - id (uuid, primary key)
     - list_id (uuid, FK to shortage_lists)
     - product_id (uuid, nullable FK to products)
     - product_name (text) — اسم الصنف محفوظ
     - notes (text, nullable) — ملاحظات
     - created_at (timestamptz)

2. الأمان
   - تفعيل RLS على كلا الجدولين
   - السماح لـ anon و authenticated بكامل CRUD لأن التطبيق بدون تسجيل دخول
*/

CREATE TABLE IF NOT EXISTS shortage_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  list_date date NOT NULL UNIQUE,
  archived_at timestamptz DEFAULT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE shortage_lists ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_shortage_lists" ON shortage_lists;
CREATE POLICY "anon_select_shortage_lists" ON shortage_lists FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_shortage_lists" ON shortage_lists;
CREATE POLICY "anon_insert_shortage_lists" ON shortage_lists FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_shortage_lists" ON shortage_lists;
CREATE POLICY "anon_update_shortage_lists" ON shortage_lists FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_shortage_lists" ON shortage_lists;
CREATE POLICY "anon_delete_shortage_lists" ON shortage_lists FOR DELETE
  TO anon, authenticated USING (true);

-- ─────────────────────────────────────────────────────────

CREATE TABLE IF NOT EXISTS shortage_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  list_id uuid NOT NULL REFERENCES shortage_lists(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS shortage_items_list_id_idx ON shortage_items(list_id);

ALTER TABLE shortage_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_shortage_items" ON shortage_items;
CREATE POLICY "anon_select_shortage_items" ON shortage_items FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_shortage_items" ON shortage_items;
CREATE POLICY "anon_insert_shortage_items" ON shortage_items FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_shortage_items" ON shortage_items;
CREATE POLICY "anon_update_shortage_items" ON shortage_items FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_shortage_items" ON shortage_items;
CREATE POLICY "anon_delete_shortage_items" ON shortage_items FOR DELETE
  TO anon, authenticated USING (true);
