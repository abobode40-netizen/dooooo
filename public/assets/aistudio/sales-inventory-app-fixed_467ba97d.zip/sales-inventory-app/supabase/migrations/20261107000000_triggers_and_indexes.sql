/*
# تحسينات: تحديث updated_at تلقائياً + فهارس مفقودة

1. updated_at لم يكن يتغيّر أبداً عند التعديل (التطبيق لا يرسله) → trigger على products / customers / customer_debts
2. فهارس للأعمدة المستخدمة في الاستعلامات والـ JOIN (sale_items.product_id، price_change_items.product_id، ...)
3. قيود سلامة بسيطة (غير مانعة للبيانات الحالية: NOT VALID) على الأرقام السالبة

الهجرة آمنة لإعادة التشغيل (idempotent).
*/

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_products_updated_at ON products;
CREATE TRIGGER trg_products_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_customers_updated_at ON customers;
CREATE TRIGGER trg_customers_updated_at BEFORE UPDATE ON customers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

DROP TRIGGER IF EXISTS trg_customer_debts_updated_at ON customer_debts;
CREATE TRIGGER trg_customer_debts_updated_at BEFORE UPDATE ON customer_debts
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();

CREATE INDEX IF NOT EXISTS idx_sale_items_product_id ON sale_items (product_id);
CREATE INDEX IF NOT EXISTS idx_price_change_items_product_id ON price_change_items (product_id);
CREATE INDEX IF NOT EXISTS idx_shortage_items_product_id ON shortage_items (product_id);
CREATE INDEX IF NOT EXISTS idx_cash_denoms_session_id ON cash_counter_denominations (session_id);
CREATE INDEX IF NOT EXISTS idx_products_created_at ON products (created_at DESC);

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'products_prices_nonneg') THEN
    ALTER TABLE products ADD CONSTRAINT products_prices_nonneg
      CHECK (price >= 0 AND price_wholesale >= 0 AND cost >= 0) NOT VALID;
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'customer_debts_amounts_nonneg') THEN
    ALTER TABLE customer_debts ADD CONSTRAINT customer_debts_amounts_nonneg
      CHECK (account_total >= 0 AND paid_amount >= 0) NOT VALID;
  END IF;
END $$;
