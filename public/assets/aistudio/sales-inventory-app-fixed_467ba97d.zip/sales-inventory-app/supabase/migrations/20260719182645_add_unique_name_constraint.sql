-- Add a unique index on the normalized name so duplicates can't exist at the DB level.
-- We use a LOWER(TRIM(name)) expression index so "أرز" and " أرز " are treated as the same.
-- This makes upsert-by-name safe and prevents the duplicate-creation bug.

-- First, verify there are no existing normalized-name duplicates (there shouldn't be).
-- If any existed, this migration would fail — which is the correct safety behavior.

CREATE UNIQUE INDEX IF NOT EXISTS products_name_normalized_uniq
  ON products (LOWER(TRIM(name)));
