/*
# Create customer debts (مديونية العملاء) tables

1. New Tables
- `customer_debts` — سجل ديون العملاء
  - `id` (uuid, primary key)
  - `customer_name` (text, not null) — اسم العميل
  - `customer_phone` (text, nullable) — رقم هاتف العميل للواتساب
  - `account_total` (numeric, not null, default 0) — حساب العميل (الإجمالي المستحق)
  - `paid_amount` (numeric, not null, default 0) — المدفوع
  - `remaining` (numeric, generated) — الباقي = account_total - paid_amount
  - `notes` (text, nullable) — ملاحظات
  - `created_at` (timestamptz, default now())
  - `updated_at` (timestamptz, default now())

2. Security
- Enable RLS on `customer_debts`.
- Allow anon + authenticated CRUD (single-tenant, no sign-in app).
*/

CREATE TABLE IF NOT EXISTS customer_debts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  customer_phone text,
  account_total numeric(12,2) NOT NULL DEFAULT 0,
  paid_amount numeric(12,2) NOT NULL DEFAULT 0,
  remaining numeric(12,2) GENERATED ALWAYS AS (account_total - paid_amount) STORED,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE customer_debts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_debts" ON customer_debts;
CREATE POLICY "anon_select_debts" ON customer_debts FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_debts" ON customer_debts;
CREATE POLICY "anon_insert_debts" ON customer_debts FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_debts" ON customer_debts;
CREATE POLICY "anon_update_debts" ON customer_debts FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_debts" ON customer_debts;
CREATE POLICY "anon_delete_debts" ON customer_debts FOR DELETE
  TO anon, authenticated USING (true);

-- Index for sorting by date
CREATE INDEX IF NOT EXISTS idx_customer_debts_created_at ON customer_debts (created_at DESC);
