/*
# Create cash counter tables (single-tenant, no auth)

1. New Tables
- `cash_counter_sessions`: each counting session (customer name, total, date)
  - id (uuid PK)
  - customer_name (text, nullable)
  - total_amount (numeric, default 0)
  - session_date (date)
  - created_at (timestamptz)
- `cash_counter_denominations`: denomination breakdown per session
  - id (uuid PK)
  - session_id (uuid FK -> cash_counter_sessions)
  - denomination_value (numeric) — e.g. 200, 100, 50, 20, 10, 5
  - count (integer) — number of notes/coins
  - subtotal (numeric) — denomination_value * count
  - created_at (timestamptz)
2. Security
- Enable RLS on both tables.
- Allow anon + authenticated CRUD (single-tenant, intentionally shared).
*/

CREATE TABLE IF NOT EXISTS cash_counter_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text,
  total_amount numeric NOT NULL DEFAULT 0,
  session_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cash_counter_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_cash_sessions" ON cash_counter_sessions;
CREATE POLICY "anon_select_cash_sessions" ON cash_counter_sessions FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_cash_sessions" ON cash_counter_sessions;
CREATE POLICY "anon_insert_cash_sessions" ON cash_counter_sessions FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_cash_sessions" ON cash_counter_sessions;
CREATE POLICY "anon_update_cash_sessions" ON cash_counter_sessions FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_cash_sessions" ON cash_counter_sessions;
CREATE POLICY "anon_delete_cash_sessions" ON cash_counter_sessions FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS cash_counter_denominations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES cash_counter_sessions(id) ON DELETE CASCADE,
  denomination_value numeric NOT NULL,
  count integer NOT NULL DEFAULT 0,
  subtotal numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cash_counter_denominations ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_cash_denoms" ON cash_counter_denominations;
CREATE POLICY "anon_select_cash_denoms" ON cash_counter_denominations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_cash_denoms" ON cash_counter_denominations;
CREATE POLICY "anon_insert_cash_denoms" ON cash_counter_denominations FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_cash_denoms" ON cash_counter_denominations;
CREATE POLICY "anon_update_cash_denoms" ON cash_counter_denominations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_cash_denoms" ON cash_counter_denominations;
CREATE POLICY "anon_delete_cash_denoms" ON cash_counter_denominations FOR DELETE
  TO anon, authenticated USING (true);
