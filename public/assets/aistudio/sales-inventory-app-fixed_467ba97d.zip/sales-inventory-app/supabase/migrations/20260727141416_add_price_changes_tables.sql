/*
# جداول زيادات الأسعار اليومية

1. جداول جديدة
   - `price_snapshots`: لقطة آخر أسعار معروفة لكل صنف (للمقارنة الذكية)
     - product_id (uuid, FK to products, unique)
     - price_wholesale (numeric)
     - price_retail (numeric)
     - updated_at (timestamptz)
   - `price_change_days`: قائمة يومية لزيادات الأسعار
     - id (uuid, primary key)
     - day_date (date, unique)
     - created_at (timestamptz)
   - `price_change_items`: أصناف زادت أسعارها في يوم محدد
     - id (uuid, primary key)
     - day_id (uuid, FK to price_change_days, ON DELETE CASCADE)
     - product_id (uuid, FK to products, ON DELETE SET NULL)
     - product_name (text)
     - code (text, nullable)
     - price_wholesale (numeric) — السعر الجديد جملة
     - price_retail (numeric) — السعر الجديد تجزئة
     - old_price_wholesale (numeric) — السعر القديم جملة
     - old_price_retail (numeric) — السعر القديم تجزئة
     - created_at (timestamptz)

2. الأمان
   - RLS مفعّل على كل الجداول
   - anon + authenticated لديهم صلاحية CRUD كاملة (تطبيق بدون تسجيل دخول)
*/

-- ── price_snapshots ──
CREATE TABLE IF NOT EXISTS price_snapshots (
  product_id uuid PRIMARY KEY REFERENCES products(id) ON DELETE CASCADE,
  price_wholesale numeric(12,2) NOT NULL DEFAULT 0,
  price_retail numeric(12,2) NOT NULL DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE price_snapshots ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_all_price_snapshots" ON price_snapshots;
CREATE POLICY "anon_all_price_snapshots" ON price_snapshots FOR ALL
  TO anon, authenticated USING (true) WITH CHECK (true);

-- ── price_change_days ──
CREATE TABLE IF NOT EXISTS price_change_days (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  day_date date NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE price_change_days ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_all_price_change_days" ON price_change_days;
CREATE POLICY "anon_all_price_change_days" ON price_change_days FOR ALL
  TO anon, authenticated USING (true) WITH CHECK (true);

-- ── price_change_items ──
CREATE TABLE IF NOT EXISTS price_change_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  day_id uuid NOT NULL REFERENCES price_change_days(id) ON DELETE CASCADE,
  product_id uuid REFERENCES products(id) ON DELETE SET NULL,
  product_name text NOT NULL,
  code text DEFAULT '',
  price_wholesale numeric(12,2) NOT NULL DEFAULT 0,
  price_retail numeric(12,2) NOT NULL DEFAULT 0,
  old_price_wholesale numeric(12,2) NOT NULL DEFAULT 0,
  old_price_retail numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

CREATE INDEX IF NOT EXISTS price_change_items_day_id_idx ON price_change_items(day_id);

ALTER TABLE price_change_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_all_price_change_items" ON price_change_items;
CREATE POLICY "anon_all_price_change_items" ON price_change_items FOR ALL
  TO anon, authenticated USING (true) WITH CHECK (true);
