ALTER TABLE customer_debts ADD COLUMN IF NOT EXISTS customer_address text;
