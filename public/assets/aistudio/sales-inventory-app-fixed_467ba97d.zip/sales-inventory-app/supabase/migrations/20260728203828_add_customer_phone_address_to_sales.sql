/*
# Add customer phone and address to sales table

1. Modified Tables
- `sales`: add `customer_phone` (text, nullable) and `customer_address` (text, nullable)
2. Security
- No RLS changes — existing policies already cover these columns.
*/

ALTER TABLE sales ADD COLUMN IF NOT EXISTS customer_phone text;
ALTER TABLE sales ADD COLUMN IF NOT EXISTS customer_address text;
