/*
# Add product code, unit, and wholesale price columns

1. Modified Tables
- `products`:
  - `code` (text) — item code/SKU (nullable, unique-friendly)
  - `unit` (text) — unit of measure (piece, kg, box, etc.)
  - `price_wholesale` (numeric) — wholesale selling price (سعر البيع جمله)
  - existing `price` column remains as the retail price (سعر البيع تجزئة)

2. Notes
- No data is lost. New columns are nullable / have defaults.
- `price` continues to represent the retail (تجزئة) price.
- An index on `code` is added for fast search by code.
*/

ALTER TABLE products
  ADD COLUMN IF NOT EXISTS code text,
  ADD COLUMN IF NOT EXISTS unit text,
  ADD COLUMN IF NOT EXISTS price_wholesale numeric(12,2) NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS idx_products_code ON products(code);
