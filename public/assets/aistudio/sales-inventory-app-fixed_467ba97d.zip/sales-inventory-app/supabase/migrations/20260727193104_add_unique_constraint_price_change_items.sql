-- Prevent duplicate items for the same product on the same day
DELETE FROM price_change_items
WHERE id IN (
  SELECT id FROM (
    SELECT id, ROW_NUMBER() OVER (PARTITION BY day_id, product_id ORDER BY created_at ASC) as rn
    FROM price_change_items
  ) t WHERE rn > 1
);

ALTER TABLE price_change_items
  ADD CONSTRAINT price_change_items_day_product_unique UNIQUE (day_id, product_id);