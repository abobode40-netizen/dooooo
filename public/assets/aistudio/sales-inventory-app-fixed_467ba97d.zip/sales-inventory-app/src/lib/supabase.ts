import { createClient } from '@supabase/supabase-js';
const url = import.meta.env.VITE_SUPABASE_URL as string;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;
export const supabase = createClient(url, anonKey);
export type Product = {
  id: string; code: string | null; name: string; unit: string | null;
  barcode: string | null; price: number; price_wholesale: number; cost: number;
  stock: number; category: string | null; created_at: string; updated_at: string;
};
export type Customer = {
  id: string; code: string | null; name: string; phone1: string | null; phone2: string | null;
  address: string | null; notes: string | null; created_at: string; updated_at: string;
};
